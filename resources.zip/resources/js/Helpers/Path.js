export const baseUrl = (path) => {
    return 'http://127.0.0.1:8000/'+path;
}
